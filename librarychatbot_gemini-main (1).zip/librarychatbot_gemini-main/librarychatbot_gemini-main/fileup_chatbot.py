import os
import streamlit as st
import nest_asyncio
import tempfile
import hashlib # (✅ 변경) 파일 해시(hash) 생성을 위해 추가

# Streamlit에서 비동기 작업을 위한 이벤트 루프 설정
nest_asyncio.apply()

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.output_parsers import StrOutputParser
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.history_aware_retriever import create_history_aware_retriever
from langchain_community.chat_message_histories.streamlit import StreamlitChatMessageHistory

__import__('pysqlite3')
import sys
sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')
from langchain_chroma import Chroma

# PDF 파일 업로드 챗봇봇

#Gemini API 키 설정
try:
    os.environ["GOOGLE_API_KEY"] = st.secrets["GOOGLE_API_KEY"]
except Exception as e:
    st.error("⚠️ GOOGLE_API_KEY를 Streamlit Secrets에 설정해주세요!")
    st.stop()

def load_and_split_pdf(file_path):
    """PDF 파일을 로드하고 텍스트 조각으로 분할합니다."""
    loader = PyPDFLoader(file_path)
    pages = loader.load_and_split()
    
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    split_docs = text_splitter.split_documents(pages)
    st.info(f"📄 {len(split_docs)}개의 텍스트 청크로 분할했습니다.")
    return split_docs

# (✅ 변경) file_bytes_content를 인자로 받도록 수정
@st.cache_resource
def initialize_components(selected_model, file_bytes_content):
    """
    업로드된 파일 바이트를 기반으로 전체 RAG 체인을 초기화하고 캐시합니다.
    파일 바이트가 동일하면 캐시된 체인을 반환합니다.
    """
    
    # 1. 파일 바이트를 임시 파일(tempfile)로 디스크에 저장
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tf:
        tf.write(file_bytes_content)
        temp_file_path = tf.name
    
    st.info(f"'{temp_file_path}' 에서 PDF 로드 중...")
    
    try:
        # 2. 임시 파일 경로를 사용해 PDF 로드 및 분할
        split_docs = load_and_split_pdf(temp_file_path)
        
    finally:
        # 3. 처리가 끝나면 임시 파일 삭제
        os.remove(temp_file_path)

    # (✅✅✅ 핵심 변경 사항: 파일 기반 DB로 변경)
    # 4. 파일 내용의 해시(hash)를 기반으로 고유한 폴더 경로 생성
    file_hash = hashlib.md5(file_bytes_content).hexdigest()
    persist_directory = f"./chroma_db_{file_hash}" # 예: ./chroma_db_abc123...
    
    st.info("🤖 임베딩 모델 로드 중...")
    embeddings = HuggingFaceEmbeddings(
        model_name="jhgan/ko-sroberta-multitask", #"sentence-transformers/all-MiniLM-L6-v2",
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': True}
    )
    
    # 5. 해당 파일의 전용 DB가 이미 디스크에 있는지 확인
    if os.path.exists(persist_directory):
        st.info("🔄 기존에 생성된 벡터 DB를 재사용합니다.")
        vectorstore = Chroma(
            persist_directory=persist_directory,
            embedding_function=embeddings
        )
    else:
        st.info("🔢 새 벡터 DB 생성 및 저장 중... (파일별 1회 수행)")
        vectorstore = Chroma.from_documents(
            split_docs,
            embeddings,
            persist_directory=persist_directory # 디스크에 저장
        )
        st.success("💾 벡터 데이터베이스 생성 완료!")
    # (✅✅✅ 변경 끝)
        
    retriever = vectorstore.as_retriever()

    # 채팅 히스토리 요약 시스템 프롬프트 (이하 동일)
    contextualize_q_system_prompt = """...[생략]..."""
    contextualize_q_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", contextualize_q_system_prompt),
            MessagesPlaceholder("history"),
            ("human", "{input}"),
        ]
    )

    # 질문-답변 시스템 프롬프트 (이하 동일)
    qa_system_prompt = """...[생략]..."""
    # qa_system_prompt 변수를 제거하고 문자열을 직접 전달합니다.
    qa_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", """You are an assistant for question-answering tasks. \
    Use the following pieces of retrieved context to answer the question. \
    If you don't know the answer, just say that you don't know. \
    Keep the answer perfect. please use imogi with the answer.
    대답은 한국어로 하고, 존댓말을 써줘.\

    {context}"""), # <--- 이렇게 문자열을 직접 전달합니다.
            MessagesPlaceholder("history"),
            ("human", "{input}"),
        ]
    )

    try:
        llm = ChatGoogleGenerativeAI(
            model=selected_model,
            temperature=0.7,
            convert_system_message_to_human=True
        )
    except Exception as e:
        st.error(f"❌ Gemini 모델 '{selected_model}' 로드 실패: {str(e)}")
        st.info("💡 'gemini-pro' 모델을 사용해보세요.")
        raise
        
    history_aware_retriever = create_history_aware_retriever(llm, retriever, contextualize_q_prompt)
    question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
    rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)
    return rag_chain

# --- Streamlit UI (이전과 동일) ---
st.header("나만의 PDF Q&A 챗봇 💬 📚")
st.info("RAG 챗봇을 테스트할 PDF 파일을 업로드해주세요.")

# 1. 파일 업로드 위젯
uploaded_file = st.file_uploader("PDF 파일을 선택하세요.", type="pdf")

if uploaded_file:
    # 2. 파일이 업로드되면, 파일의 바이트(내용)를 읽음
    file_bytes = uploaded_file.getvalue()

    # 3. 채팅 히스토리 관리
    chat_history = StreamlitChatMessageHistory(key="chat_messages")
    
    # 4. 새 파일 감지 및 히스토리 초기화
    if "last_file_id" not in st.session_state or st.session_state.last_file_id != uploaded_file.file_id:
        st.session_state.last_file_id = uploaded_file.file_id
        chat_history.clear()
        st.info(f"'{uploaded_file.name}' 파일에 대한 새 대화를 시작합니다.")
        chat_history.add_ai_message(f"'{uploaded_file.name}'에 대해 무엇이든 물어보세요!")

    # 5. Gemini 모델 선택
    option = st.selectbox("Select Gemini Model",
        ("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash-exp"), 
        index=0,
        help="Gemini 2.5 Flash가 가장 빠르고 효율적입니다."
    )

    # 6. RAG 체인 초기화 (파일 바이트를 키로 사용하여 캐시)
    try:
        with st.spinner("🔧 챗봇 초기화 중... (파일 처리 및 임베딩 중)"):
            rag_chain = initialize_components(option, file_bytes)
        st.success("✅ 챗봇이 준비되었습니다!")
    except Exception as e:
        st.error(f"⚠️ 초기화 중 오류 발생: {str(e)}")
        st.info("PDF 파일이 손상되지 않았는지, API 키가 유효한지 확인해주세요.")
        st.stop()

    # 7. 대화형 RAG 체인 구성
    conversational_rag_chain = RunnableWithMessageHistory(
        rag_chain,
        lambda session_id: chat_history,
        input_messages_key="input",
        history_messages_key="history",
        output_messages_key="answer",
    )

    # 8. 채팅 기록 표시
    for msg in chat_history.messages:
        st.chat_message(msg.type).write(msg.content)

    # 9. 사용자 입력 처리
    if prompt_message := st.chat_input(f"'{uploaded_file.name}'에 대해 질문하기"):
        st.chat_message("human").write(prompt_message)
        with st.chat_message("ai"):
            with st.spinner("Thinking..."):
                config = {"configurable": {"session_id": "any"}}
                # 💥 오류가 발생했던 부분
                response = conversational_rag_chain.invoke(
                    {"input": prompt_message},
                    config
                )
                
                answer = response['answer']
                st.write(answer)
                
                # 참고 문맥 표시
                with st.expander("참고 문서 확인"):
                    for doc in response['context']:
                        source = doc.metadata.get('source', '알 수 없음')
                        page = doc.metadata.get('page', '알 수 없음')
                        st.markdown(f"**출처: {os.path.basename(source)} (Page: {page + 1})**", help=doc.page_content)

else:
    # 파일이 업로드되지 않았을 때 표시할 메시지
    st.info("👆 PDF 파일을 업로드하면 챗봇이 활성화됩니다.")
