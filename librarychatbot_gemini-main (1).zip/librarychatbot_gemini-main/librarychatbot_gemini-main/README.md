# librarychatbot_gemini
RAG기반 챗봇 gemini key 사용

기본 RAG 기반 QnA 챗봇(챗봇 동작 확인용)

https://chris-qnachatbot.streamlit.app/


<img width="1187" height="636" alt="image" src="https://github.com/user-attachments/assets/23b4bd95-3a25-47ac-aef4-386133e26fb4" />

