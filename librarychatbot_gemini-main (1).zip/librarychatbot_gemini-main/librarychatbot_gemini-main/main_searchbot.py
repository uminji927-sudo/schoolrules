# 💬 검색 기능이 추가된 대화형 챗봇 (Agent)
import os
import streamlit as st
import nest_asyncio

# Streamlit에서 비동기 작업을 위한 이벤트 루프 설정
nest_asyncio.apply()

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories.streamlit import StreamlitChatMessageHistory

# 🔽 [추가] 에이전트와 도구(Tool) 관련 import
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain.agents import Tool
from langchain_community.utilities import GoogleSearchAPIWrapper

# --- 1. API 키 설정 (Gemini + Google Search) ---
try:
    # Gemini API 키
    os.environ["GOOGLE_API_KEY"] = st.secrets["GOOGLE_API_KEY"]
    # Google Search API 키
    os.environ["GOOGLE_API_KEY"] = st.secrets["GOOGLE_SEARCH_API_KEY"]
    # Google Search CSE ID
    os.environ["GOOGLE_CSE_ID"] = st.secrets["GOOGLE_CSE_ID"]
except KeyError as e:
    st.error(f"⚠️ {e}가 Streamlit Secrets에 설정되지 않았습니다!")
    st.info("Gemini API 키, Google Search API 키, Google CSE ID가 모두 필요합니다.")
    st.stop()


# --- 2. 챗봇 에이전트 생성 (캐시) ---
@st.cache_resource(show_spinner="🤖 챗봇 에이전트 구성 중...")
def get_chat_agent_executor(selected_model):
    """
    LLM, 검색 도구(Tool), 프롬프트를 결합하여
    대화형 에이전트(AgentExecutor)를 생성합니다.
    """
    
    # 1. LLM 로드
    try:
        llm = ChatGoogleGenerativeAI(
            model=selected_model,
            temperature=0.7,
            convert_system_message_to_human=True
        )
    except Exception as e:
        st.error(f"❌ Gemini 모델 '{selected_model}' 로드 실패: {str(e)}")
        st.stop()

    # 2. 🔽 [추가] Google 검색 도구(Tool) 설정
    try:
        search_wrapper = GoogleSearchAPIWrapper(
            google_api_key=os.environ["GOOGLE_SEARCH_API_KEY"],
            google_cse_id=os.environ["GOOGLE_CSE_ID"]
        )
        search_tool = Tool(
            name="google_search",
            description="""
            현재 시간, 날씨, 뉴스, 특정 주제에 대한 최신 정보,
            사실 확인(fact-checking)이 필요할 때 사용합니다.
            일반적인 대화나 잡담에는 사용하지 않습니다.
            """,
            func=search_wrapper.run,
        )
        tools = [search_tool]
    except Exception as e:
        st.error(f"❌ Google Search 도구 초기화 실패: {e}")
        st.info("Google Cloud에서 'Custom Search API'를 활성화했는지, CSE ID가 올바른지 확인하세요.")
        st.stop()

    # 3. 🔽 [변경] 에이전트용 프롬프트 설정
    # 에이전트가 도구 사용을 포함한 내부 작업을 기록할 'agent_scratchpad'가 추가됩니다.
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", """
            당신은 친절하고 유머러스한 AI 어시스턴트 '제미니'입니다. 
            항상 한국어와 존댓말을 사용하며, 대화에 이모지를 적절히 섞어 답해주세요. 🤖
            
            당신은 'google_search'라는 도구를 사용할 수 있습니다.
            사용자가 날씨, 최신 뉴스, 실시간 정보 등 검색이 필요한 질문을 하면,
            반드시 이 도구를 사용하여 최신 정보를 검색한 후 답변해야 합니다.
            """),
            MessagesPlaceholder("history"), # 대화 기록
            ("human", "{input}"),         # 사용자 입력
            MessagesPlaceholder("agent_scratchpad"), # 👈 [추가] 에이전트 작업 기록
        ]
    )
    
    # 4. 🔽 [추가] 에이전트 생성
    # LLM이 도구를 호출할 수 있도록 에이전트를 생성합니다.
    agent = create_tool_calling_agent(llm, tools, prompt)

    # 5. 🔽 [추가] 에이전트 실행기(AgentExecutor) 생성
    # 에이전트 로직을 실제로 실행할 실행기입니다.
    agent_executor = AgentExecutor(
        agent=agent, 
        tools=tools, 
        verbose=True # 👈 (디버깅용) 터미널에 에이전트의 생각 과정을 출력
    )
    
    return agent_executor

# --- 3. Streamlit UI 설정 ---

st.header("나의 검색 챗봇 (Agent) 💬🔍")
st.info("일상 대화도 가능하고, '오늘 날씨' 같은 검색도 가능해요!")

# 채팅 기록을 Streamlit의 세션 상태에 저장
chat_history = StreamlitChatMessageHistory(key="chat_messages")

# 모델 선택
option = st.selectbox("Select Gemini Model",
    ("gemini-2.5-pro","gemini-2.5-flash"),
    index=0,
    help="도구 사용(Tool Calling)이 가능한 최신 모델을 권장합니다."
)

# 🔽 [변경] LLM 체인 대신 에이전트 실행기(AgentExecutor)를 가져옵니다.
agent_executor = get_chat_agent_executor(option)

# 🔽 [변경] 에이전트 실행기를 대화 기록과 연결
conversational_agent_chain = RunnableWithMessageHistory(
    agent_executor,
    lambda session_id: chat_history,
    input_messages_key="input",
    history_messages_key="history",
    # 🔽 [변경] 에이전트의 최종 답변은 'output' 키에 저장됩니다.
    output_messages_key="output", 
    # 🔽 [추가] 에이전트의 중간 작업(tool call) 기록을 전달
    agent_scratchpad_messages_key="agent_scratchpad", 
)

# --- 4. 채팅 UI 로직 ---

# 첫 방문 시 환영 메시지 추가
if not chat_history.messages:
    chat_history.add_ai_message("안녕하세요! 만나서 반가워요. 😊 무엇이든 물어보세요! (예: 안양시 오늘 날씨)")

# 이전 대화 기록 모두 출력
for msg in chat_history.messages:
    st.chat_message(msg.type).write(msg.content)

# 사용자 입력 받기
if prompt_message := st.chat_input("메시지를 입력하세요..."):
    st.chat_message("human").write(prompt_message)
    
    with st.chat_message("ai"):
        with st.spinner("Thinking... (검색이 필요하면 조금 더 걸려요)"):
            config = {"configurable": {"session_id": "any_id"}}
            
            # 🔽 [변경] 체인을 실행하고, 결과(dict)에서 'output' 키를 추출합니다.
            response = conversational_agent_chain.invoke(
                {"input": prompt_message},
                config
            )
            
            # 에이전트의 최종 답변은 response 딕셔너리의 'output' 키에 있습니다.
            st.write(response["output"])
