# 📄 PDF Q&A 챗봇 (Fallback 기능 추가 버전)
import os
import streamlit as st
import nest_asyncio
import tempfile
import hashlib

# Streamlit에서 비동기 작업을 위한 이벤트 루프 설정
nest_asyncio.apply()

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.output_parsers import StrOutputParser
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.history_aware_retriever import create_history_aware_retriever
from langchain_community.chat_message_histories.streamlit import StreamlitChatMessageHistory

# pysqlite3 임포트 (ChromaDB 호환성)
__import__('pysqlite3')
import sys
sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')
from langchain_chroma import Chroma


#Gemini API 키 설정
try:
    os.environ["GOOGLE_API_KEY"] = st.secrets["GOOGLE_API_KEY"]
except Exception as e:
    st.error("⚠️ GOOGLE_API_KEY를 Streamlit Secrets에 설정해주세요!")
    st.stop()

def load_and_split_pdf(file_path, original_filename):
    """PDF 파일을 로드하고 'source' 메타데이터를 수정한 뒤 텍스트 조각으로 분할합니다."""
    loader = PyPDFLoader(file_path)
    pages = loader.load_and_split()
    
    # 'source' 메타데이터를 임시 파일 경로 대신 원본 파일 이름으로 덮어쓰기
    for page in pages:
        page.metadata["source"] = original_filename

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    split_docs = text_splitter.split_documents(pages)
    st.info(f"📄 {len(split_docs)}개의 텍스트 청크로 분할했습니다.")
    return split_docs

@st.cache_resource
def initialize_components(selected_model, file_bytes_content, original_filename):
    """
    업로드된 파일 바이트와 파일 이름을 기반으로 전체 RAG 체인을 초기화하고 캐시합니다.
    """
    
    # 1. 파일 바이트를 임시 파일(tempfile)로 디스크에 저장
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tf:
        tf.write(file_bytes_content)
        temp_file_path = tf.name
    
    st.info(f"'{original_filename}' 파일 로드 중...")
    
    try:
        # 2. 임시 파일 경로와 '원본 파일 이름'을 함께 전달
        split_docs = load_and_split_pdf(temp_file_path, original_filename)
        
    finally:
        # 3. 처리가 끝나면 임시 파일 삭제
        os.remove(temp_file_path)

    # 4. 파일 내용의 해시(hash)를 기반으로 고유한 폴더 경로 생성
    file_hash = hashlib.md5(file_bytes_content).hexdigest()
    persist_directory = f"./chroma_db_{file_hash}" 
    
    st.info("🤖 임베딩 모델 로드 중... (모델 변경 시 새로 다운로드)")
    
    # 한국어 특화 임베딩 모델
    model_name = "jhgan/ko-sroberta-multitask" 
    embeddings = HuggingFaceEmbeddings(
        model_name=model_name,
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': True}
    )
    
    # 5. 해당 파일의 전용 DB가 이미 디스크에 있는지 확인
    if os.path.exists(persist_directory):
        st.info("🔄 기존에 생성된 벡터 DB를 재사용합니다.")
        vectorstore = Chroma(
            persist_directory=persist_directory,
            embedding_function=embeddings
        )
    else:
        st.info("🔢 새 벡터 DB 생성 및 저장 중... (파일별 1회 수행)")
        vectorstore = Chroma.from_documents(
            split_docs,
            embeddings,
            persist_directory=persist_directory 
        )
        st.success("💾 벡터 데이터베이스 생성 완료!")
    
    # 6. 검색기(Retriever) 설정 (k=10)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 10})

    # 7. 채팅 히스토리 요약 시스템 프롬프트 (동일)
    contextualize_q_system_prompt = """Given a chat history and the latest user question \
    which might reference context in the chat history, formulate a standalone question \
    which can be understood without the chat history. Do NOT answer the question, \
    just reformulate it if needed and otherwise return it as is."""
    contextualize_q_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", contextualize_q_system_prompt),
            MessagesPlaceholder("history"),
            ("human", "{input}"),
        ]
    )

    # 8. (✅✅✅ 핵심 변경 사항: Fallback 프롬프트 적용)
    # RAG 답변 + LLM 일반 지식 답변 (Fallback)을 모두 처리하도록 프롬프트 수정
    qa_system_prompt = """당신은 친절하고 예의바른 Q&A 어시스턴트입니다.
    사용자의 질문에 대해 답변하는 것이 당신의 임무입니다.
    당신에게는 PDF 문서에서 검색된 문맥(context)이 주어집니다.

    다음 지침을 순서대로 따르세요:
    1.  먼저, 주어진 검색된 문맥({context}) 내에서 질문에 대한 답변을 찾으려고 노력하세요.
    2.  만약 문맥에서 답변을 찾을 수 없다면, 당신의 일반 지식을 사용하여 질문에 답하세요.
    3.  일반 지식을 사용하여 답변할 경우, "PDF 문서에는 관련 내용이 없습니다만," 또는 "일반적인 정보에 따르면," 과 같이 답변이 문서에서 온 것이 아님을 명확히 밝혀주세요.
    4.  항상 한국어와 존댓말을 사용하여 답변해주세요.
    5.  적절한 경우 이모지를 사용하여 답변을 꾸며주세요.

    [검색된 문맥]
    {context}
    """
    
    qa_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", qa_system_prompt), # 👈 변경된 Fallback 프롬프트 적용
            MessagesPlaceholder("history"),
            ("human", "{input}"),
        ]
    )

    # 9. LLM 및 RAG 체인 구성 (이하 동일)
    try:
        llm = ChatGoogleGenerativeAI(
            model=selected_model,
            temperature=0.7,
            convert_system_message_to_human=True
        )
    except Exception as e:
        st.error(f"❌ Gemini 모델 '{selected_model}' 로드 실패: {str(e)}")
        st.info("💡 'gemini-pro' 모델을 사용해보세요.")
        raise
        
    history_aware_retriever = create_history_aware_retriever(llm, retriever, contextualize_q_prompt)
    question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
    rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)
    return rag_chain

# --- Streamlit UI (1번 코드와 동일) ---
st.header("나만의 PDF Q&A 챗봇 💬 📚")
st.info("RAG 챗봇을 테스트할 PDF 파일을 업로드해주세요. (PDF에 답이 없으면 일반 답변 제공)")

uploaded_file = st.file_uploader("PDF 파일을 선택하세요.", type="pdf")

if uploaded_file:
    file_bytes = uploaded_file.getvalue()
    chat_history = StreamlitChatMessageHistory(key="chat_messages")
    
    # 파일이 변경되면 대화 기록 초기화
    if "last_file_id" not in st.session_state or st.session_state.last_file_id != uploaded_file.file_id:
        st.session_state.last_file_id = uploaded_file.file_id
        chat_history.clear()
        st.info(f"'{uploaded_file.name}' 파일에 대한 새 대화를 시작합니다.")
        chat_history.add_ai_message(f"'{uploaded_file.name}'에 대해 무엇이든 물어보세요!")

    option = st.selectbox("Select Gemini Model",
        ("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash-exp"), # (모델명 최신화)
        index=0,
        help="Gemini 2.5 Flash가 가장 빠르고 효율적입니다."
    )

    try:
        with st.spinner("🔧 챗봇 초기화 중... (파일 처리 및 임베딩 중)"):
            rag_chain = initialize_components(option, file_bytes, uploaded_file.name)
        st.success("✅ 챗봇이 준비되었습니다!")
    except Exception as e:
        st.error(f"⚠️ 초기화 중 오류 발생: {str(e)}")
        st.info("PDF 파일이 손상되지 않았는지, API 키가 유효한지 확인해주세요.")
        st.stop()

    # 채팅 기록을 RAG 체인에 연결
    conversational_rag_chain = RunnableWithMessageHistory(
        rag_chain,
        lambda session_id: chat_history,
        input_messages_key="input",
        history_messages_key="history",
        output_messages_key="answer",
    )

    # 이전 대화 기록 출력
    for msg in chat_history.messages:
        st.chat_message(msg.type).write(msg.content)

    # 사용자 입력 처리
    if prompt_message := st.chat_input(f"'{uploaded_file.name}'에 대해 질문하기"):
        st.chat_message("human").write(prompt_message)
        
        with st.chat_message("ai"):
            with st.spinner("Thinking..."):
                config = {"configurable": {"session_id": "any"}}
                response = conversational_rag_chain.invoke(
                    {"input": prompt_message},
                    config
                )
                
                answer = response['answer']
                st.write(answer)
                
                # 답변 근거가 된 문맥(context) 출력
                with st.expander("참고 문서 확인"):
                    if not response['context']:
                         st.info("PDF 내에서 참고할 만한 문서를 찾지 못했습니다. (일반 지식 답변)")
                    
                    for doc in response['context']:
                        source = doc.metadata.get('source', '알 수 없음') 
                        # page 번호는 0-based index이므로 +1
                        page = doc.metadata.get('page', '알 수 없음')
                        if page != '알 수 없음':
                            page += 1 
                            
                        st.markdown(f"**출처: {source} (Page: {page})**", help=doc.page_content)

else:
    st.info("👆 PDF 파일을 업로드하면 챗봇이 활성화됩니다.")
