# 📄 PDF&일상주제 Q&A 챗봇
import os
import streamlit as st
import nest_asyncio
import tempfile
import hashlib

# Streamlit에서 비동기 작업을 위한 이벤트 루프 설정
nest_asyncio.apply()

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.runnables import RunnablePassthrough # 👈 [추가]
from langchain_core.output_parsers import StrOutputParser
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.history_aware_retriever import create_history_aware_retriever
from langchain_community.chat_message_histories.streamlit import StreamlitChatMessageHistory

# pysqlite3 임포트 (ChromaDB 호환성)
__import__('pysqlite3')
import sys
sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')
from langchain_chroma import Chroma


#Gemini API 키 설정
try:
    os.environ["GOOGLE_API_KEY"] = st.secrets["GOOGLE_API_KEY"]
except Exception as e:
    st.error("⚠️ GOOGLE_API_KEY를 Streamlit Secrets에 설정해주세요!")
    st.stop()

# --- (1) RAG 체인 관련 함수들 (기존과 동일) ---

def load_and_split_pdf(file_path, original_filename):
    """PDF 파일을 로드하고 'source' 메타데이터를 수정한 뒤 텍스트 조각으로 분할합니다."""
    loader = PyPDFLoader(file_path)
    pages = loader.load_and_split()
    
    for page in pages:
        page.metadata["source"] = original_filename

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    split_docs = text_splitter.split_documents(pages)
    st.info(f"📄 {len(split_docs)}개의 텍스트 청크로 분할했습니다.")
    return split_docs

@st.cache_resource(show_spinner="🔧 RAG 챗봇 초기화 중...")
def initialize_rag_chain(selected_model, file_bytes_content, original_filename):
    """
    (이름 변경: initialize_components -> initialize_rag_chain)
    업로드된 파일을 기반으로 RAG 체인을 초기화하고,
    RunnableWithMessageHistory 객체를 반환합니다.
    """
    
    # 1. 파일 바이트를 임시 파일로 저장
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tf:
        tf.write(file_bytes_content)
        temp_file_path = tf.name
    
    st.info(f"'{original_filename}' 파일 로드 중...")
    try:
        split_docs = load_and_split_pdf(temp_file_path, original_filename)
    finally:
        os.remove(temp_file_path)

    # 4. 파일 해시 기반으로 ChromaDB 경로 설정
    file_hash = hashlib.md5(file_bytes_content).hexdigest()
    persist_directory = f"./chroma_db_{file_hash}" 
    
    st.info("🤖 임베딩 모델 로드 중...")
    model_name = "jhgan/ko-sroberta-multitask" 
    embeddings = HuggingFaceEmbeddings(
        model_name=model_name,
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': True}
    )
    
    # 5. ChromaDB 생성 또는 로드
    if os.path.exists(persist_directory):
        st.info("🔄 기존 벡터 DB 재사용 중.")
        vectorstore = Chroma(
            persist_directory=persist_directory,
            embedding_function=embeddings
        )
    else:
        st.info("🔢 새 벡터 DB 생성 중...")
        vectorstore = Chroma.from_documents(
            split_docs,
            embeddings,
            persist_directory=persist_directory 
        )
        st.success("💾 벡터 DB 생성 완료!")
    
    retriever = vectorstore.as_retriever(search_kwargs={"k": 10})

    # 7. 히스토리 요약 프롬프트
    contextualize_q_system_prompt = """Given a chat history and the latest user question \
    which might reference context in the chat history, formulate a standalone question \
    which can be understood without the chat history. Do NOT answer the question, \
    just reformulate it if needed and otherwise return it as is."""
    contextualize_q_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", contextualize_q_system_prompt),
            MessagesPlaceholder("history"),
            ("human", "{input}"),
        ]
    )

    # 8. RAG + Fallback 프롬프트
    # RAG 답변 + LLM 일반 지식 답변 (Fallback)을 모두 처리하도록 프롬프트 수정
    qa_system_prompt = """당신은 친절하고 예의바른 Q&A 어시스턴트입니다.
    사용자의 질문에 대해 답변하는 것이 당신의 임무입니다.
    당신에게는 PDF 문서에서 검색된 문맥(context)이 주어집니다.

    다음 지침을 순서대로 따르세요:
    1.  먼저, 주어진 검색된 문맥({context}) 내에서 질문에 대한 답변을 찾으려고 노력하세요.
    2.  만약 문맥에서 답변을 찾을 수 없다면, 당신의 일반 지식을 사용하여 질문에 답하세요.
    3.  일반 지식을 사용하여 답변할 경우, "PDF 문서에는 관련 내용이 없습니다만," 또는 "일반적인 정보에 따르면," 과 같이 답변이 문서에서 온 것이 아님을 명확히 밝혀주세요.
    4.  항상 한국어와 존댓말을 사용하여 답변해주세요.
    5.  적절한 경우 이모지를 사용하여 답변을 꾸며주세요.

    [검색된 문맥]
    {context}
    """
    qa_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", qa_system_prompt),
            MessagesPlaceholder("history"),
            ("human", "{input}"),
        ]
    )

    # 9. LLM 및 RAG 체인 구성
    try:
        llm = ChatGoogleGenerativeAI(
            model=selected_model,
            temperature=0.7,
            convert_system_message_to_human=True
        )
    except Exception as e:
        st.error(f"❌ Gemini 모델 '{selected_model}' 로드 실패: {str(e)}")
        st.stop()
        
    history_aware_retriever = create_history_aware_retriever(llm, retriever, contextualize_q_prompt)
    question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
    rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)
    
    # 10. (✅ 변경) RunnableWithMessageHistory 객체를 생성하여 반환
    conversational_rag_chain = RunnableWithMessageHistory(
        rag_chain,
        lambda session_id: StreamlitChatMessageHistory(key="chat_messages"),
        input_messages_key="input",
        history_messages_key="history",
        output_messages_key="answer",
    )
    return conversational_rag_chain


# --- (2) 👈 [새 함수 추가] 일반 대화 체인 ---

@st.cache_resource(show_spinner="💬 일반 챗봇 초기화 중...")
def get_general_chat_chain(selected_model):
    """
    RAG 없이 LLM과 직접 대화하는 일반 채팅 체인을 초기화하고,
    RunnableWithMessageHistory 객체를 반환합니다.
    """
    
    try:
        llm = ChatGoogleGenerativeAI(
            model=selected_model,
            temperature=0.7,
            convert_system_message_to_human=True
        )
    except Exception as e:
        st.error(f"❌ Gemini 모델 '{selected_model}' 로드 실패: {str(e)}")
        st.stop()

    # 일반 대화용 프롬프트
    general_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "당신은 친절한 AI 챗봇입니다. 항상 한국어로 예의 바르게, 이모지를 사용하며 대답해주세요. 🤖"),
            MessagesPlaceholder("history"),
            ("human", "{input}"),
        ]
    )
    
    # 일반 대화 체인 (RAG 체인과 출력 형식을 맞추기 위해 'answer' 키 사용)
    # 입력: {"input": "..."}
    # 출력: {"answer": "..."}
    general_chain = (
        general_prompt
        | llm
        | StrOutputParser()
    )
    
    # RAG 체인('rag_chain')이 'answer' 키를 포함한 dict를 반환하므로,
    # 일반 체인도 동일한 출력을 갖도록 RunnablePassthrough.assign을 사용합니다.
    chain_with_answer_key = RunnablePassthrough.assign(
        answer=general_chain
    )

    # RunnableWithMessageHistory 객체를 생성하여 반환
    conversational_general_chain = RunnableWithMessageHistory(
        chain_with_answer_key,
        lambda session_id: StreamlitChatMessageHistory(key="chat_messages"),
        input_messages_key="input",
        history_messages_key="history",
        output_messages_key="answer", # 'answer' 키에서 AI 답변을 가져와 히스토리에 저장
    )
    return conversational_general_chain


# --- (3)  Streamlit UI (로직 변경) ---

st.header("chrisLin 일상주제 및 PDF Q&A 챗봇 💬 📚")

# 1. 채팅 기록을 먼저 초기화 (전역)
chat_history = StreamlitChatMessageHistory(key="chat_messages")

# 2. 모델 선택 (전역)
option = st.selectbox("Select Gemini Model",
    ("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash-exp"),
    index=0,
    help="Gemini 2.5 Flash가 가장 빠르고 효율적입니다."
)

# 3. 파일 업로더 (전역)
uploaded_file = st.file_uploader("PDF 파일을 선택하세요.", type="pdf")

# 4. (✅✅✅ 핵심 로직) 파일 업로드 여부에 따라 다른 체인 사용
if uploaded_file:
    # --- RAG 모드 ---
    st.info("PDF 기반 RAG 챗봇 모드입니다. 🤖")
    file_bytes = uploaded_file.getvalue()
    
    # 파일이 변경되면 대화 기록 초기화
    if "last_file_id" not in st.session_state or st.session_state.last_file_id != uploaded_file.file_id:
        st.session_state.last_file_id = uploaded_file.file_id
        chat_history.clear()
        st.info(f"'{uploaded_file.name}' 파일에 대한 새 대화를 시작합니다.")
        chat_history.add_ai_message(f"'{uploaded_file.name}'에 대해 무엇이든 물어보세요!")

    try:
        conversational_chain = initialize_rag_chain(option, file_bytes, uploaded_file.name)
        st.success("✅ PDF 챗봇이 준비되었습니다!")
    except Exception as e:
        st.error(f"⚠️ PDF 챗봇 초기화 중 오류 발생: {str(e)}")
        st.stop()
    
    placeholder_text = f"'{uploaded_file.name}'에 대해 질문하기"

else:
    # --- 일반 대화 모드 ---
    st.info("👆 PDF를 업로드하면 RAG 모드가 활성화됩니다. (현재: 일반 대화 모드)")
    
    # 새 파일이 아닌 '일반 대화'로 전환될 때도 히스토리 초기화
    if "last_file_id" in st.session_state:
        del st.session_state["last_file_id"]
        chat_history.clear()
        st.info("일반 대화를 시작합니다.")
        chat_history.add_ai_message("무엇이든 물어보세요! 😊")
        
    try:
        conversational_chain = get_general_chat_chain(option)
    except Exception as e:
        st.error(f"⚠️ 일반 챗봇 초기화 중 오류 발생: {str(e)}")
        st.stop()
        
    placeholder_text = "무엇이든 물어보세요..."

# --- (5) 공통 채팅 UI ---

# 이전 대화 기록 출력
for msg in chat_history.messages:
    st.chat_message(msg.type).write(msg.content)

# 사용자 입력 처리
if prompt_message := st.chat_input(placeholder_text):
    st.chat_message("human").write(prompt_message)
    
    with st.chat_message("ai"):
        with st.spinner("Thinking..."):
            config = {"configurable": {"session_id": "any"}}
            
            # (✅ 변경) 두 모드(RAG/일반) 모두 {"input": ...} 형식으로 호출
            response = conversational_chain.invoke(
                {"input": prompt_message},
                config
            )
            
            # (✅ 변경) 두 모드(RAG/일반) 모두 'answer' 키로 답변 받음
            answer = response['answer']
            st.write(answer)
            
            # (✅✅✅ 핵심 변경) 'context' 키가 있는 경우 (RAG 모드)에만 참고 문서 표시
            if 'context' in response:
                with st.expander("참고 문서 확인"):
                    if not response['context']:
                         st.info("PDF 내에서 참고할 만한 문서를 찾지 못했습니다. (일반 지식 답변)")
                    
                    for doc in response['context']:
                        source = doc.metadata.get('source', '알 수 없음') 
                        page = doc.metadata.get('page', '알 수 없음')
                        if page != '알 수 없음':
                            page += 1 
                        st.markdown(f"**출처: {source} (Page: {page})**", help=doc.page_content)
